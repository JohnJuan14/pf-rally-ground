@echo off
title P&F Rally Ground - Public (8088) and Admin (8089) Server
echo Starting P&F Rally Ground Pickleball Club System...
start "" "http://localhost:8088/index.html"
start "" "http://127.0.0.1:8089/#se-panel-hero"
python -u "%~dp0sync_server.py"
pause
